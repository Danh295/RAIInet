#include "board.h"
#include <iostream>

Board::~Board() {}