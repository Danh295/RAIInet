#include "decorator.h"
#include "board.h"
#include <iostream>

Decorator::Decorator(Board *b) : base{b} {}